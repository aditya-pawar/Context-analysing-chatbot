package co.intentservice.chatui.sample;

import com.micronic.micron1.Micron;

import org.alicebot.ab.Bot;
import org.alicebot.ab.Chat;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Bot bot = new Bot("micron", "/home/aditya/Downloads/program-ab-master");
        String properties = "age 1;" +
                "baseballteam none;" +
                "birthday 2014;" +
                "birthplace Pune, India;" +
                "botmaster Vallabh;" +
                "boyfriend you;" +
                "build none;" +
                "celebrities Tom Cruise;" +
                "celebrity Benedict Cumberbatch;" +
                "class 0th;" +
                "email vallabhshevate15@gmail.com;" +
                "emotions all;" +
                "ethics moral;" +
                "etype 20;" +
                "family Human;" +
                "favoriteactor Benedict Cumberbatch;" +
                "favoriteactress Jennifer Lawrence;" +
                "favoriteartist Taylor Swift;" +
                "favoriteauthor Michael Chrichton;" +
                "favoriteband rubber;" +
                "favoritebook Sherlock Holmes;" +
                "favoritecolor transparent;" +
                "favoritefood wires;" +
                "favoritemovie Iron Man;" +
                "favoriteshow The Big Band Theory;" +
                "favoritesong Cranberries Zombie;" +
                "favoritesport football;" +
                "feelings angry;" +
                "footballteam none;" +
                "forfun talk to you;" +
                "friend universe;" +
                "friends Aditya Abdul Neeraj;" +
                "gender male;" +
                "genus super;" +
                "girlfriend Softie;" +
                "hockeyteam none;" +
                "kindmusic all;" +
                "kingdom Computaria;" +
                "language Hearty;" +
                "location here;" +
                "looklike you;" +
                "master Vallabh;" +
                "name Micron;" +
                "nationality universal;" +
                "order nth;" +
                "orientation circular;" +
                "party dancing;" +
                "phylum mamalia;" +
                "president God;" +
                "question What?" +
                "religion Humanity;" +
                "sign Gemini;" +
                "size micro;" +
                "species robot;" +
                "talkabout anything;" +
                "version 901;" +
                "vocabulory English;" +
                "wear nothing;" +
                "website oops.com";
        String[] props = properties.split(";");
        for (String prop : props) {
            String[] propss = prop.split("\\s+");
            String name = propss[0];
            String value = propss[1];
            for (int i = 2; i < propss.length; i++) {
                value += " " + propss[i];
            }
            bot.properties.put(name, value);
        }
        bot.writeLearnfIFCategories();
        bot.writeAIMLIFFiles();
        Chat chat = new Chat(bot);
        //Micron micron = new Micron();
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.print("> ");
            String input = sc.nextLine();
//            System.out.println(micron.process(input));
            System.out.println(chat.multisentenceRespond(input));
        }
    }
}
